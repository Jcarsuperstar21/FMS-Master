class MatchupGameRunner {
  constructor() {
    this.circleMatched = false;
    this.rectMatched = false;

    this.circleStartX = 100;
    this.circleStartY = 100;

    this.rectStartX = 200;
    this.rectStartY = 50;

    this.circleX = 100;
    this.circleY = 100;

    this.rectX = 200;
    this.rectY = 50;

    this.selected = "";
    this.offsetX = 0;
    this.offsetY = 0;
  }

  draw() {
    background(245);
    strokeWeight(10);

    // Targets
    fill(220);
    circle(1000, 100, 100);
    rect(950, 200, 100, 100);

    line(540, 0, 540, 1920);

    // Draggable circle
    fill(0, 190, 180);
    circle(this.circleX, this.circleY, 100);

    // Draggable rectangle
    fill(200, 0, 20);
    rect(this.rectX, this.rectY, 100, 100);
  }

  mousePressed() {
    if (
      !this.circleMatched &&
      dist(mouseX, mouseY, this.circleX, this.circleY) < 50
    ) {
      this.selected = "circle";
      this.offsetX = mouseX - this.circleX;
      this.offsetY = mouseY - this.circleY;
    } else if (
      !this.rectMatched &&
      mouseX >= this.rectX && mouseX <= this.rectX + 100 &&
      mouseY >= this.rectY && mouseY <= this.rectY + 100
    ) {
      this.selected = "rect";
      this.offsetX = mouseX - this.rectX;
      this.offsetY = mouseY - this.rectY;
    }
  }

  mouseDragged() {
    if (this.selected === "circle") {
      this.circleX = mouseX - this.offsetX;
      this.circleY = mouseY - this.offsetY;
    } else if (this.selected === "rect") {
      this.rectX = mouseX - this.offsetX;
      this.rectY = mouseY - this.offsetY;
    }
  }

  mouseReleased() {
    if (this.selected === "circle") {
      if (dist(this.circleX, this.circleY, 1000, 100) < 60) {
        this.circleX = 1000;
        this.circleY = 100;
        this.circleMatched = true;
      } else {
        this.circleX = this.circleStartX;
        this.circleY = this.circleStartY;
      }
    } else if (this.selected === "rect") {
      if (dist(this.rectX, this.rectY, 950, 200) < 60) {
        this.rectX = 950;
        this.rectY = 200;
        this.rectMatched = true;
      } else {
        this.rectX = this.rectStartX;
        this.rectY = this.rectStartY;
      }
    }

    this.selected = "";
  }
}

let game;

// function setup() {
//   createCanvas(1080, 1920);
//   game = new MatchupGameRunner();
// }

// function draw() {
//   game.draw();
// }

// function mousePressed() {
  // game.mousePressed();


// function mouseDragged() {
  // game.mouseDragged();


// function mouseReleased() {
  // game.mouseReleased();

